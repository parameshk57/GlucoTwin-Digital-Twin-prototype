"""GlucoTwin synthetic model: fuse EHR + wearable streams, forecast 2-hour glucose event."""
from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, average_precision_score, confusion_matrix,
                             f1_score, precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
MODEL_DIR = ROOT / "models"
TARGET = "spike_event_2h"
FEATURES = [
    "age_years", "bmi_kg_m2", "diabetes_duration_years", "hba1c_percent",
    "hypertension_flag", "metformin_flag", "medication_adherence_0_1", "family_history_flag",
    "current_glucose_mg_dl", "glucose_slope_mgdl_hr", "heart_rate_bpm", "hrv_ms",
    "steps_last_hour", "sleep_hours_previous_night", "meal_carbs_g_logged", "hour_of_day",
]


def load_fused_data():
    ehr = pd.read_csv(DATA_DIR / "synthetic_ehr.csv")
    wearable = pd.read_csv(DATA_DIR / "synthetic_wearable_hourly.csv", parse_dates=["timestamp"])
    labels = pd.read_csv(DATA_DIR / "synthetic_labels_2h.csv", parse_dates=["timestamp"])
    fused = wearable.merge(ehr, on="patient_id", how="inner", validate="many_to_one")
    fused = fused.merge(labels, on=["patient_id", "timestamp"], how="inner", validate="one_to_one")
    fused["hour_of_day"] = fused["timestamp"].dt.hour.astype(int)
    fused = fused.sort_values(["patient_id", "timestamp"]).reset_index(drop=True)
    if fused[FEATURES + [TARGET]].isna().any().any():
        raise ValueError("Unexpected missing values in synthetic fused training data")
    return fused


def train_and_evaluate(data=None):
    df = load_fused_data() if data is None else data.copy()
    patients = np.array(sorted(df["patient_id"].unique()))
    train_patients, test_patients = train_test_split(patients, test_size=0.25, random_state=42)
    train_mask = df["patient_id"].isin(train_patients)
    test_mask = df["patient_id"].isin(test_patients)
    X_train, y_train = df.loc[train_mask, FEATURES], df.loc[train_mask, TARGET].astype(int)
    X_test, y_test = df.loc[test_mask, FEATURES], df.loc[test_mask, TARGET].astype(int)
    model = RandomForestClassifier(
        n_estimators=160, max_depth=14, min_samples_leaf=5,
        max_features="sqrt", class_weight="balanced_subsample",
        random_state=42, n_jobs=-1,
    )
    model.fit(X_train, y_train)
    probs = model.predict_proba(X_test)[:, 1]
    preds = (probs >= 0.5).astype(int)
    cm = confusion_matrix(y_test, preds, labels=[0, 1])
    metrics = {
        "n_patients": int(len(patients)),
        "n_rows": int(len(df)),
        "n_train_patients": int(len(train_patients)),
        "n_test_patients": int(len(test_patients)),
        "n_train_rows": int(train_mask.sum()),
        "n_test_rows": int(test_mask.sum()),
        "event_prevalence": float(df[TARGET].mean()),
        "test_event_prevalence": float(y_test.mean()),
        "roc_auc": float(roc_auc_score(y_test, probs)),
        "average_precision": float(average_precision_score(y_test, probs)),
        "accuracy_at_0_5": float(accuracy_score(y_test, preds)),
        "precision_at_0_5": float(precision_score(y_test, preds, zero_division=0)),
        "recall_at_0_5": float(recall_score(y_test, preds, zero_division=0)),
        "f1_at_0_5": float(f1_score(y_test, preds, zero_division=0)),
        "confusion_matrix_tn_fp_fn_tp": cm.ravel().tolist(),
        "feature_importance": {k: float(v) for k, v in sorted(
            zip(FEATURES, model.feature_importances_), key=lambda kv: kv[1], reverse=True
        )},
        "split_method": "Patient-level holdout (75% train patients / 25% unseen test patients)",
        "threshold": 0.5,
        "random_seed": 42,
        "label_definition": "Synthetic CGM reading at timestamp + 2 hours >= 180 mg/dL",
    }
    return model, metrics, df


def save_model_bundle(model, metrics, path=None):
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    path = Path(path) if path else MODEL_DIR / "glucotwin_rf.joblib"
    joblib.dump({"model": model, "features": FEATURES, "metrics": metrics}, path, compress=3)
    with (MODEL_DIR / "evaluation_metrics.json").open("w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)
    return path

if __name__ == "__main__":
    model, metrics, df = train_and_evaluate()
    path = save_model_bundle(model, metrics)
    print(json.dumps(metrics, indent=2))
    print(f"Saved model bundle: {path}")

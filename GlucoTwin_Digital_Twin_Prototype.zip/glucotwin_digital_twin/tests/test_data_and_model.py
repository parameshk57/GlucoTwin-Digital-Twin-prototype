from pathlib import Path
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))
from twin_model import FEATURES, TARGET, load_fused_data, train_and_evaluate


def test_expected_data_stream_sizes_and_join_keys():
    ehr = pd.read_csv(ROOT / "data" / "synthetic_ehr.csv")
    wearable = pd.read_csv(ROOT / "data" / "synthetic_wearable_hourly.csv")
    labels = pd.read_csv(ROOT / "data" / "synthetic_labels_2h.csv")
    assert ehr["patient_id"].nunique() == 320
    assert len(wearable) == 320 * 7 * 24
    assert len(labels) == 320 * (7 * 24 - 2)
    assert wearable["patient_id"].nunique() == ehr["patient_id"].nunique()


def test_fused_training_features_exclude_future_outcome_columns():
    df = load_fused_data()
    assert set(FEATURES).issubset(df.columns)
    assert TARGET in df.columns
    assert "future_glucose_2h_mg_dl" not in FEATURES
    assert "spike_event_2h" not in FEATURES
    assert not df[FEATURES + [TARGET]].isna().any().any()


def test_patient_level_holdout_metrics_are_well_formed():
    model, metrics, df = train_and_evaluate()
    assert metrics["n_train_patients"] + metrics["n_test_patients"] == metrics["n_patients"]
    assert metrics["n_train_rows"] + metrics["n_test_rows"] == len(df)
    assert 0 <= metrics["roc_auc"] <= 1
    assert 0 <= metrics["recall_at_0_5"] <= 1
    sample = df.loc[df.index[0], FEATURES].to_frame().T
    probability = model.predict_proba(sample)[:, 1][0]
    assert 0 <= probability <= 1

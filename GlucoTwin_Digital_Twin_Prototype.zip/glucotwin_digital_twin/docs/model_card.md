# Model Card — GlucoTwin Synthetic Glucose Forecast

## Model summary

- **Task:** predict whether a synthetic CGM reading two hours after the current observation is at least 180 mg/dL.
- **Model:** `sklearn.ensemble.RandomForestClassifier` with 160 trees, maximum depth 14, minimum leaf size 5, square-root feature subsampling, and balanced-sub-sample class weighting.
- **Intended use:** hackathon demonstration of joining EHR and wearable streams in a virtual patient interface.
- **Out-of-scope use:** medical diagnosis, triage, prescribing, patient monitoring or other clinical decisions.

## Data

The repository generates 320 synthetic patient profiles with seven days of hourly readings per patient. There are 53,760 wearable observations and 53,120 two-hour labels (last two hours per patient lack a forward label). All values are procedurally generated, with seed `20261024`; they are not copied from real patient records. See `data_dictionary.md` and `generate_synthetic_data.py`.

## Inputs

Static EHR: age, BMI, diabetes duration, HbA1c, hypertension flag, metformin flag, simulated medication adherence, family-history flag.

Dynamic: current glucose, hourly glucose slope, heart rate, HRV, steps, previous-night sleep duration, logged carbohydrate estimate and hour of day.

## Label

`spike_event_2h = 1` when the synthetic glucose observation exactly two hourly rows after the current timestamp is `>=180 mg/dL`. It is a synthetic label definition for this experiment, not a clinical standard.

## Validation

Split is done by patient ID: 240 patients train the classifier and 80 distinct patients form the test set. There are 39,840 train rows and 13,280 test rows. Reported synthetic test metrics at score threshold 0.50: ROC-AUC 0.967, average precision 0.961, accuracy 0.898, precision 0.865, recall 0.923 and F1 0.893. Random seed for the model split is 42.

## Limitations and risks

1. Synthetic data are produced by a known, simplified simulator; metrics may be materially optimistic and do not indicate performance on real people.
2. Synthetic target prevalence is 46.0% in the test windows. This is not a population prevalence estimate.
3. Calibration, external validity, subgroup fairness, prospective utility, alert burden, clinical review and human-factors studies have not been performed.
4. The model may learn simulated time-of-day and process artifacts. Feature importance is not causal.
5. A score threshold is not clinically selected. Changing it affects the balance between false positives and false negatives.
6. No patient-specific physiological equations or biological mechanistic solver are present; this is a data-driven virtual-patient *prototype*, not a high-fidelity whole-body digital twin.

## Ethical use statement

Use only for software demonstration and method prototyping. Do not enter or infer real patient data. Do not use outputs to make or recommend care decisions. Clinical deployment would require governed real-world data, independent validation, calibration, clinician oversight, safety monitoring and regulatory/privacy review.
